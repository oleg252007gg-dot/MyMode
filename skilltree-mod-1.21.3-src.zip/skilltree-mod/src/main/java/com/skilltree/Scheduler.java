package com.skilltree;

import net.minecraft.server.world.ServerWorld;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Простейший планировщик задач по тикам сервера (для длящихся заклинаний). */
public final class Scheduler {
    /** Возвращает true, когда задача закончена. */
    @FunctionalInterface
    public interface Task { boolean tick(int age); }

    private static final class Entry {
        final ServerWorld w; final Task t; final int dur; int age;
        Entry(ServerWorld w, Task t, int dur) { this.w = w; this.t = t; this.dur = dur; }
    }

    private static final List<Entry> LIST = new ArrayList<>();
    private static final List<Entry> PENDING = new ArrayList<>();

    public static void add(ServerWorld w, int duration, Task t) { PENDING.add(new Entry(w, t, duration)); }

    public static void delay(ServerWorld w, int ticks, Runnable r) {
        add(w, ticks + 1, age -> {
            if (age >= ticks) { r.run(); return true; }
            return false;
        });
    }

    public static void clear() { LIST.clear(); PENDING.clear(); }

    public static void tick() {
        if (!PENDING.isEmpty()) { LIST.addAll(PENDING); PENDING.clear(); }
        Iterator<Entry> it = LIST.iterator();
        while (it.hasNext()) {
            Entry e = it.next();
            boolean done;
            try { done = e.t.tick(e.age); }
            catch (Throwable ex) { SkillTreeMod.LOG.error("Ошибка в задаче заклинания", ex); done = true; }
            if (done || ++e.age >= e.dur) it.remove();
        }
    }
}
