package com.skilltree;

import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.Items;

import java.util.*;

/** Определения всех навыков трёх веток. */
public final class Skills {
    public static final List<Skill> ALL = new ArrayList<>();
    private static final Map<String, Skill> BY_ID = new HashMap<>();
    private static final Map<Branch, List<Skill>> BY_BRANCH = new EnumMap<>(Branch.class);

    public static Skill get(String id) { return BY_ID.get(id); }
    public static List<Skill> of(Branch b) { return BY_BRANCH.getOrDefault(b, List.of()); }
    public static int minCol(Branch b) { return of(b).stream().mapToInt(s -> s.col).min().orElse(0); }
    public static int maxCol(Branch b) { return of(b).stream().mapToInt(s -> s.col).max().orElse(0); }
    public static int maxRow(Branch b) { return of(b).stream().mapToInt(s -> s.row).max().orElse(0); }

    private static void reg(Skill s) {
        if (BY_ID.containsKey(s.id)) throw new IllegalStateException("Дубликат навыка " + s.id);
        ALL.add(s); BY_ID.put(s.id, s);
        BY_BRANCH.computeIfAbsent(s.branch, k -> new ArrayList<>()).add(s);
    }

    private static void root(Branch b, int col, Skill s) { s.branch = b; s.col = col; s.row = 0; reg(s); }

    private static void path(Branch b, int col, String parent, Skill... list) {
        String prev = parent; int row = 1;
        for (Skill s : list) { s.branch = b; s.col = col; s.row = row++; s.parent = prev; prev = s.id; reg(s); }
    }

    private static Skill p(String id, String n, String d, ItemConvertible i, int c) { return new Skill(id, n, d, i, c); }
    private static Skill a(String id, String n, String d, ItemConvertible i, int c, String ab) { return new Skill(id, n, d, i, c).ab(ab); }
    private static Skill g(String id, String n, String d, Item weapon, int c) { return new Skill(id, n, d, weapon, c).gr(weapon); }

    public static void init() {
        // ============================== МАГИЯ ==============================
        Branch M = Branch.MAGIC;
        root(M, 3, p("m_root", "Искра магии", "Пробуждает магический дар. +20 к максимуму маны.", Items.ENDER_EYE, 1).s(Stat.MAX_MANA, 20));
        path(M, 0, "m_root",
            a("m_fireball", "Огненный шар", "Метает огненный шар: взрыв радиусом 3.5, урон 7, поджог.", Items.FIRE_CHARGE, 2, "fireball"),
            p("m_fire_mastery", "Мастер огня", "+20% к урону огненных заклинаний.", Items.BLAZE_POWDER, 2).s(Stat.FIRE_POWER, 0.20),
            a("m_fire_wall", "Огненная стена", "Стена пламени шириной 10 блоков на 8 секунд. Жжёт и поджигает всех, кто в ней.", Items.MAGMA_BLOCK, 3, "fire_wall"),
            a("m_fire_nova", "Огненная нова", "Вспышка пламени вокруг вас: радиус 7, урон 8, поджог, отбрасывание.", Items.BLAZE_ROD, 3, "fire_nova"),
            a("m_meteor", "Метеорит", "Через 2 секунды с неба падает метеорит: радиус 7, урон 22, сильный поджог.", Items.CRYING_OBSIDIAN, 5, "meteor"));
        path(M, 1, "m_root",
            a("m_ice_shard", "Ледяной шип", "Пронзающий ледяной луч (до 3 целей): урон 8, заморозка и замедление.", Items.PRISMARINE_SHARD, 2, "ice_shard"),
            p("m_frost_mastery", "Мастер льда", "+20% к урону ледяных заклинаний.", Items.SNOWBALL, 2).s(Stat.FROST_POWER, 0.20),
            a("m_ice_wall", "Ледяная стена", "Стена льда на 8 секунд: замораживает и сильно замедляет проходящих.", Items.PACKED_ICE, 3, "ice_wall"),
            a("m_frost_nova", "Ледяная нова", "Волна холода радиусом 7: урон 5, глубокая заморозка.", Items.BLUE_ICE, 3, "frost_nova"),
            a("m_hail", "Град", "5 секунд ледяных осколков с неба в области радиусом 6.", Items.POWDER_SNOW_BUCKET, 4, "hail"));
        path(M, 2, "m_root",
            p("m_mana1", "Резерв маны I", "+30 к максимуму маны.", Items.LAPIS_LAZULI, 1).s(Stat.MAX_MANA, 30),
            p("m_regen1", "Поток маны I", "+1 мана в секунду.", Items.AMETHYST_SHARD, 1).s(Stat.MANA_REGEN, 1.0),
            p("m_mana2", "Резерв маны II", "+50 к максимуму маны.", Items.LAPIS_BLOCK, 2).s(Stat.MAX_MANA, 50),
            p("m_regen2", "Поток маны II", "+1.5 маны в секунду.", Items.AMETHYST_BLOCK, 2).s(Stat.MANA_REGEN, 1.5),
            p("m_cost1", "Экономия маны I", "-10% к стоимости заклинаний.", Items.ECHO_SHARD, 3).s(Stat.MANA_COST_RED, 0.10));
        path(M, 3, "m_root",
            a("m_stream", "Поток магии", "3 секунды вы изливаете луч чистой магии в направлении взгляда. Урон каждые 0.2 с.", Items.ENCHANTED_BOOK, 3, "arcane_stream"),
            p("m_spell1", "Сила заклинаний I", "+15% к урону всех заклинаний.", Items.GLOWSTONE_DUST, 2).s(Stat.SPELL_POWER, 0.15),
            p("m_cd1", "Быстрое чтение I", "-10% к перезарядке способностей.", Items.REPEATER, 2).s(Stat.COOLDOWN_RED, 0.10),
            p("m_spell2", "Сила заклинаний II", "+20% к урону всех заклинаний.", Items.GLOWSTONE, 3).s(Stat.SPELL_POWER, 0.20),
            p("m_cd2", "Быстрое чтение II", "-15% к перезарядке способностей.", Items.COMPASS, 3).s(Stat.COOLDOWN_RED, 0.15));
        path(M, 4, "m_root",
            a("m_decay", "Аура разложения", "10 секунд вокруг вас гниёт всё живое: иссушение, слабость и урон врагам в радиусе 5.", Items.WITHER_ROSE, 3, "decay_aura"),
            a("m_drain", "Похищение жизни", "Луч тьмы: урон 6 цели, вы лечитесь на 4.", Items.SPIDER_EYE, 3, "life_drain"),
            p("m_manashield", "Мана-щит", "30% получаемого урона компенсируется за счёт маны (2 маны за 1 ХП).", Items.SHIELD, 3).s(Stat.MANA_SHIELD, 0.30),
            a("m_blackhole", "Чёрная дыра", "4 секунды затягивает всех в радиусе 9, затем схлопывается взрывом (урон 8).", Items.SCULK_CATALYST, 5, "black_hole"),
            p("m_spell3", "Сила заклинаний III", "+25% к урону всех заклинаний.", Items.NETHER_STAR, 4).s(Stat.SPELL_POWER, 0.25));
        path(M, 5, "m_root",
            a("m_chain", "Цепная молния", "Молния перескакивает между 6 врагами, теряя 15% урона на каждом прыжке (урон 7).", Items.LIGHTNING_ROD, 3, "chain_lightning"),
            a("m_blink", "Скачок", "Мгновенно телепортирует вас на 14 блоков вперёд.", Items.ENDER_PEARL, 3, "blink"),
            a("m_shock", "Ударная волна", "Мощный толчок вокруг вас: радиус 7, урон 6, сильное отбрасывание.", Items.WIND_CHARGE, 3, "shockwave"),
            a("m_timewarp", "Искажение времени", "8 секунд враги в радиусе 10 почти замирают, а вы ускоряетесь.", Items.CLOCK, 4, "time_warp"),
            p("m_cd3", "Быстрое чтение III", "-15% к перезарядке способностей.", Items.RECOVERY_COMPASS, 4).s(Stat.COOLDOWN_RED, 0.15));
        path(M, 6, "m_root",
            a("m_heal", "Исцеление", "Восстанавливает 10 ХП вам и 6 ХП союзникам рядом, даёт регенерацию.", Items.GLISTERING_MELON_SLICE, 2, "heal"),
            a("m_barrier", "Магический барьер", "20 секунд: поглощение 8 ХП и сопротивление урону.", Items.TOTEM_OF_UNDYING, 3, "barrier"),
            a("m_poison", "Ядовитое облако", "Облако яда радиусом 4 на 8 секунд.", Items.POISONOUS_POTATO, 3, "poison_cloud"),
            p("m_mana3", "Резерв маны III", "+80 к максимуму маны.", Items.EXPERIENCE_BOTTLE, 3).s(Stat.MAX_MANA, 80),
            p("m_cost2", "Экономия маны II", "-15% к стоимости заклинаний.", Items.DIAMOND, 4).s(Stat.MANA_COST_RED, 0.15));

        // ============================== БОЙ ==============================
        Branch C = Branch.COMBAT;
        root(C, 3, p("c_root", "Воинская подготовка", "+1 к урону атаки.", Items.IRON_SWORD, 1).s(Stat.ATTACK_DAMAGE, 1));
        path(C, 0, "c_root",
            g("c_dual", "Парные клинки", "Оружие: урон 5, скорость 2.8. Каждый удар сопровождается вторым (60% урона). ПКМ — вихрь клинков.", ModItems.DUAL_BLADES, 3),
            g("c_dagger", "Кинжал теней", "Оружие: урон 3.5, скорость 3.6. Удар в спину наносит двойной урон. ПКМ — теневой шаг.", ModItems.DAGGER, 3),
            a("c_shadowstep", "Теневой шаг", "Телепортирует за спину ближайшего врага и бьёт в спину (урон x2), затем 3 с невидимости.", Items.BLACK_DYE, 3, "shadow_step"),
            a("c_whirl", "Вихрь клинков", "Вы раскручиваетесь, нанося урон всем в радиусе 3.5 в течение секунды.", Items.GOLDEN_SWORD, 3, "whirlwind"),
            p("c_mastery1", "Мастерство оружия I", "+15% урона уникальным оружием мода.", Items.GOLD_INGOT, 3).s(Stat.WEAPON_MASTERY, 0.15));
        path(C, 1, "c_root",
            g("c_hammer", "Молот Титана", "Оружие: урон 12, скорость 0.9. Удар создаёт ударную волну. ПКМ — удар с прыжка.", ModItems.HAMMER, 4),
            a("c_crush", "Сокрушающий удар", "Мощный удар по конусу перед вами: урон x2.2, отбрасывание, слабость.", Items.ANVIL, 3, "crushing_blow"),
            a("c_leap", "Удар с прыжка", "Прыжок вперёд и разрушительное приземление: радиус 5.5, урон x1.8.", Items.PISTON, 3, "leap_slam"),
            p("c_mastery2", "Мастерство оружия II", "+20% урона уникальным оружием мода.", Items.GOLD_BLOCK, 4).s(Stat.WEAPON_MASTERY, 0.20),
            p("c_pen", "Пробивание брони", "+15% от урона удара наносится сверх брони.", Items.IRON_NUGGET, 3).s(Stat.ARMOR_PEN, 0.15));
        path(C, 2, "c_root",
            p("c_as1", "Проворство I", "+10% скорости атаки.", Items.FEATHER, 1).s(Stat.ATTACK_SPEED_PCT, 0.10),
            p("c_as2", "Проворство II", "+10% скорости атаки.", Items.SUGAR, 2).s(Stat.ATTACK_SPEED_PCT, 0.10),
            a("c_dash", "Рывок", "Стремительный рывок вперёд с уроном всем на пути.", Items.RABBIT_FOOT, 2, "dash"),
            p("c_as3", "Проворство III", "+15% скорости атаки.", Items.NAUTILUS_SHELL, 3).s(Stat.ATTACK_SPEED_PCT, 0.15),
            p("c_as4", "Проворство IV", "+20% скорости атаки.", Items.HEART_OF_THE_SEA, 4).s(Stat.ATTACK_SPEED_PCT, 0.20));
        path(C, 3, "c_root",
            p("c_dmg1", "Сила I", "+1 к урону атаки.", Items.STONE_SWORD, 1).s(Stat.ATTACK_DAMAGE, 1),
            p("c_dmg2", "Сила II", "+1.5 к урону атаки.", Items.DIAMOND_SWORD, 2).s(Stat.ATTACK_DAMAGE, 1.5),
            p("c_dmg3", "Сила III", "+2 к урону атаки.", Items.NETHERITE_SWORD, 3).s(Stat.ATTACK_DAMAGE, 2),
            p("c_dmg4", "Сила IV", "+15% к итоговому урону атаки.", Items.NETHERITE_INGOT, 4).s(Stat.ATTACK_DAMAGE_PCT, 0.15),
            p("c_berserk", "Берсерк", "Чем меньше у вас здоровья, тем больше урон — до +50% при почти нулевом ХП.", Items.TNT, 4).s(Stat.BERSERK, 0.50));
        path(C, 4, "c_root",
            p("c_crit1", "Меткость I", "+8% шанс критического удара.", Items.FLINT, 2).s(Stat.CRIT_CHANCE, 0.08),
            p("c_critd1", "Разрушитель I", "+25% к урону критических ударов.", Items.GOLD_NUGGET, 2).s(Stat.CRIT_DAMAGE, 0.25),
            p("c_crit2", "Меткость II", "+10% шанс критического удара.", Items.EMERALD, 3).s(Stat.CRIT_CHANCE, 0.10),
            p("c_critd2", "Разрушитель II", "+35% к урону критических ударов.", Items.EMERALD_BLOCK, 3).s(Stat.CRIT_DAMAGE, 0.35),
            p("c_exec", "Казнь", "+50% урона по врагам с менее чем 30% здоровья.", Items.WITHER_SKELETON_SKULL, 4).s(Stat.EXECUTE, 0.50));
        path(C, 5, "c_root",
            p("c_ls1", "Кровожадность I", "Лечит на 6% от нанесённого урона.", Items.GHAST_TEAR, 2).s(Stat.LIFESTEAL, 0.06),
            p("c_bleed", "Кровотечение", "30% шанс вызвать кровотечение: 5 тиков урона по 1.5.", Items.REDSTONE, 2).s(Stat.BLEED, 0.30),
            p("c_ls2", "Кровожадность II", "Лечит ещё на 8% от нанесённого урона.", Items.FERMENTED_SPIDER_EYE, 3).s(Stat.LIFESTEAL, 0.08),
            p("c_killheal", "Трофей", "+2 ХП за каждое убийство.", Items.GOLDEN_APPLE, 3).s(Stat.KILL_HEAL, 2),
            a("c_rage", "Кровавая ярость", "Жертвуете 4 ХП: сила III и скорость II на 8 секунд.", Items.RED_DYE, 4, "blood_rage"));
        path(C, 6, "c_root",
            g("c_spear", "Копьё Бури", "Оружие: урон 6.5, +1.5 к дальности. Удар бьёт молнией ещё двух врагов рядом. ПКМ — бросок клинка.", ModItems.SPEAR, 3),
            g("c_scythe", "Коса Жнеца", "Оружие: урон 8.5, +0.8 к дальности. Иссушает цель и лечит вас. ПКМ — сокрушающий удар.", ModItems.SCYTHE, 4),
            g("c_katana", "Катана Ярости", "Оружие: урон 7, скорость 1.8. Поджигает цель. ПКМ — рывок.", ModItems.KATANA, 4),
            a("c_throw", "Бросок клинка", "Пронзающий бросок на 20 блоков (до 5 целей): урон x1.4.", Items.SPECTRAL_ARROW, 3, "blade_throw"),
            p("c_mastery3", "Мастерство оружия III", "+25% урона уникальным оружием мода.", Items.NETHERITE_SCRAP, 5).s(Stat.WEAPON_MASTERY, 0.25));
        path(C, 7, "c_root",
            a("c_warcry", "Боевой клич", "Сила II и скорость на 15 с вам; враги в радиусе 9 слабеют и отступают.", Items.GOAT_HORN, 3, "war_cry"),
            a("c_stone", "Каменная кожа", "8 секунд: сильное сопротивление урону и поглощение.", Items.IRON_CHESTPLATE, 3, "stone_skin"),
            p("c_dodge1", "Уклонение I", "6% шанс полностью избежать удара.", Items.LEATHER_BOOTS, 2).s(Stat.DODGE, 0.06),
            p("c_dodge2", "Уклонение II", "+8% шанс уклониться от удара.", Items.DIAMOND_BOOTS, 3).s(Stat.DODGE, 0.08),
            p("c_thorns", "Шипы", "30% полученного урона отражается атакующему.", Items.CACTUS, 3).s(Stat.THORNS, 0.30),
            p("c_killspeed", "Азарт боя", "После убийства вы получаете скорость на 4 секунды.", Items.SWEET_BERRIES, 2).s(Stat.KILL_SPEED, 1));

        // ============================== ОБЩЕЕ ==============================
        Branch G = Branch.GENERAL;
        root(G, 3, p("g_root", "Закалка", "+2 к максимуму здоровья (1 сердце).", Items.APPLE, 1).s(Stat.MAX_HEALTH, 2));
        path(G, 0, "g_root",
            p("g_hp1", "Здоровье I", "+2 к максимуму здоровья.", Items.BREAD, 1).s(Stat.MAX_HEALTH, 2),
            p("g_hp2", "Здоровье II", "+2 к максимуму здоровья.", Items.COOKED_BEEF, 2).s(Stat.MAX_HEALTH, 2),
            p("g_hp3", "Здоровье III", "+4 к максимуму здоровья.", Items.GOLDEN_APPLE, 3).s(Stat.MAX_HEALTH, 4),
            p("g_hp4", "Здоровье IV", "+4 к максимуму здоровья.", Items.ENCHANTED_GOLDEN_APPLE, 4).s(Stat.MAX_HEALTH, 4),
            p("g_hp5", "Здоровье V", "+6 к максимуму здоровья.", Items.BEACON, 5).s(Stat.MAX_HEALTH, 6));
        path(G, 1, "g_root",
            p("g_ar1", "Броня I", "+2 к броне.", Items.LEATHER_CHESTPLATE, 1).s(Stat.ARMOR, 2),
            p("g_ar2", "Броня II", "+2 к броне.", Items.CHAINMAIL_CHESTPLATE, 2).s(Stat.ARMOR, 2),
            p("g_tough1", "Прочность I", "+1 к твёрдости брони.", Items.TURTLE_HELMET, 2).s(Stat.ARMOR_TOUGHNESS, 1),
            p("g_ar3", "Броня III", "+3 к броне.", Items.DIAMOND_CHESTPLATE, 3).s(Stat.ARMOR, 3),
            p("g_tough2", "Прочность II", "+2 к твёрдости брони.", Items.NETHERITE_CHESTPLATE, 4).s(Stat.ARMOR_TOUGHNESS, 2));
        path(G, 2, "g_root",
            p("g_sp1", "Скорость I", "+5% к скорости передвижения.", Items.IRON_BOOTS, 1).s(Stat.MOVE_SPEED, 0.05),
            p("g_sp2", "Скорость II", "+5% к скорости передвижения.", Items.GOLDEN_BOOTS, 2).s(Stat.MOVE_SPEED, 0.05),
            p("g_jump", "Прыгучесть", "Прыжок выше примерно на 12%.", Items.SLIME_BALL, 2).s(Stat.JUMP, 0.05),
            p("g_step", "Лёгкий шаг", "Вы взбираетесь на блоки без прыжка (высота шага +0.5).", Items.STONE_STAIRS, 2).s(Stat.STEP_HEIGHT, 0.5),
            p("g_sp3", "Скорость III", "+8% к скорости передвижения.", Items.NETHERITE_BOOTS, 4).s(Stat.MOVE_SPEED, 0.08));
        path(G, 3, "g_root",
            p("g_hu1", "Неприхотливость I", "Голод накапливается на 15% медленнее.", Items.COOKED_PORKCHOP, 1).s(Stat.HUNGER_SAVE, 0.15),
            p("g_hu2", "Неприхотливость II", "Голод накапливается ещё на 15% медленнее.", Items.COOKED_CHICKEN, 2).s(Stat.HUNGER_SAVE, 0.15),
            p("g_hu3", "Неприхотливость III", "Голод накапливается ещё на 20% медленнее.", Items.CAKE, 3).s(Stat.HUNGER_SAVE, 0.20),
            p("g_sat", "Вечная сытость", "Каждые 5 секунд +1 к сытости, пока вы не сыты полностью.", Items.GOLDEN_CARROT, 3).s(Stat.SATURATION, 1),
            p("g_regen", "Быстрое заживление", "+0.5 ХП в секунду, пока вы достаточно сыты.", Items.HONEY_BOTTLE, 4).s(Stat.REGEN, 0.5));
        path(G, 4, "g_root",
            p("g_haste1", "Рудокоп I", "Постоянная Спешка I.", Items.WOODEN_PICKAXE, 2).s(Stat.HASTE, 1),
            p("g_haste2", "Рудокоп II", "Спешка II (суммируется с предыдущим).", Items.DIAMOND_PICKAXE, 4).s(Stat.HASTE, 1),
            p("g_reach1", "Длинные руки I", "+1 к дальности взаимодействия с блоками.", Items.FISHING_ROD, 2).s(Stat.BLOCK_REACH, 1),
            p("g_reach2", "Длинные руки II", "+1 к дальности блоков и +0.5 к дальности атаки.", Items.BREEZE_ROD, 3).s(Stat.BLOCK_REACH, 1).s(Stat.ENTITY_REACH, 0.5),
            p("g_luck", "Удача", "+2 к удаче (лучшая добыча).", Items.NAME_TAG, 3).s(Stat.LUCK, 2));
        path(G, 5, "g_root",
            p("g_kb1", "Устойчивость I", "+15% сопротивления отбрасыванию.", Items.OBSIDIAN, 2).s(Stat.KB_RESIST, 0.15),
            p("g_kb2", "Устойчивость II", "+15% сопротивления отбрасыванию.", Items.ANCIENT_DEBRIS, 3).s(Stat.KB_RESIST, 0.15),
            p("g_nopoison", "Иммунитет к яду", "Яд на вас не действует.", Items.MILK_BUCKET, 2).s(Stat.IMMUNE_POISON, 1),
            p("g_nowither", "Чистая кровь", "Иммунитет к иссушению и эффекту голода.", Items.SOUL_SAND, 3).s(Stat.IMMUNE_WITHER, 1).s(Stat.IMMUNE_HUNGER, 1),
            p("g_secondwind", "Второе дыхание", "Смертельный урон оставляет вас с 5 сердцами. Раз в 5 минут.", Items.TOTEM_OF_UNDYING, 6).s(Stat.SECOND_WIND, 1));
        path(G, 6, "g_root",
            p("g_fire", "Огнестойкость", "Постоянное сопротивление огню.", Items.MAGMA_CREAM, 3).s(Stat.FIRE_RES, 1),
            p("g_water", "Жабры", "Дыхание под водой и больший запас воздуха.", Items.PUFFERFISH, 3).s(Stat.WATER_BREATHING, 1).s(Stat.OXYGEN, 2),
            p("g_night", "Ночное зрение", "Вы всегда хорошо видите в темноте.", Items.LANTERN, 2).s(Stat.NIGHT_VISION, 1),
            p("g_fall", "Мягкое падение", "Безопасная высота падения +4 блока.", Items.FEATHER, 2).s(Stat.SAFE_FALL, 4),
            p("g_magnet", "Магнит", "Предметы в радиусе 4 блоков сами летят к вам.", Items.LODESTONE, 3).s(Stat.MAGNET, 4));
    }
}
