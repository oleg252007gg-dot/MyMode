package com.skilltree;

import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Поиск ванильных атрибутов по id (например "max_health") — null, если такого нет. */
public final class AttrUtil {
    private static final Map<String, RegistryEntry<EntityAttribute>> CACHE = new HashMap<>();

    public static RegistryEntry<EntityAttribute> get(String id) {
        RegistryEntry<EntityAttribute> e = CACHE.get(id);
        if (e == null) {
            EntityAttribute a = Registries.ATTRIBUTE.get(Identifier.ofVanilla(id));
            if (a != null) {
                e = Registries.ATTRIBUTE.getEntry(a);
                CACHE.put(id, e);
            }
        }
        return e;
    }
}
