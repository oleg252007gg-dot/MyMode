package com.skilltree;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import java.util.List;

public record SkillData(int points, List<String> unlocked, int kills) {
    public static final SkillData EMPTY = new SkillData(0, List.of(), 0);

    public static final Codec<SkillData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Codec.INT.optionalFieldOf("points", 0).forGetter(SkillData::points),
            Codec.STRING.listOf().optionalFieldOf("unlocked", List.of()).forGetter(SkillData::unlocked),
            Codec.INT.optionalFieldOf("kills", 0).forGetter(SkillData::kills)
    ).apply(i, SkillData::new));

    public boolean has(String id) { return unlocked.contains(id); }
    public SkillData withPoints(int p) { return new SkillData(p, unlocked, kills); }
    public SkillData withUnlocked(List<String> l) { return new SkillData(points, List.copyOf(l), kills); }
    public SkillData withKills(int k) { return new SkillData(points, unlocked, k); }
}
