package com.skilltree;

import net.minecraft.server.network.ServerPlayerEntity;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Реестр активных способностей (магия + боевые умения). */
public final class Abilities {
    @FunctionalInterface public interface Cast { boolean run(ServerPlayerEntity p); }
    public record Ability(String id, String name, int mana, int cooldown, Cast cast) {}

    public static final Map<String, Ability> ALL = new LinkedHashMap<>();
    public static Ability get(String id) { return ALL.get(id); }

    private static void reg(String id, String name, int mana, int cd, Cast c) { ALL.put(id, new Ability(id, name, mana, cd, c)); }

    public static void init() {
        // --- магия ---
        reg("fireball", "Огненный шар", 15, 40, Spells::fireball);
        reg("fire_wall", "Огненная стена", 30, 200, p -> Spells.wall(p, true));
        reg("fire_nova", "Огненная нова", 35, 160, p -> Spells.nova(p, true));
        reg("meteor", "Метеорит", 80, 600, Spells::meteor);
        reg("ice_shard", "Ледяной шип", 12, 30, Spells::iceShard);
        reg("ice_wall", "Ледяная стена", 30, 200, p -> Spells.wall(p, false));
        reg("frost_nova", "Ледяная нова", 35, 160, p -> Spells.nova(p, false));
        reg("hail", "Град", 50, 400, Spells::hail);
        reg("arcane_stream", "Поток магии", 40, 160, Spells::stream);
        reg("decay_aura", "Аура разложения", 45, 400, Spells::decay);
        reg("life_drain", "Похищение жизни", 20, 100, Spells::drain);
        reg("black_hole", "Чёрная дыра", 70, 500, Spells::blackHole);
        reg("chain_lightning", "Цепная молния", 25, 80, Spells::chain);
        reg("blink", "Скачок", 20, 60, Spells::blink);
        reg("shockwave", "Ударная волна", 30, 120, Spells::shockwave);
        reg("time_warp", "Искажение времени", 60, 800, Spells::timeWarp);
        reg("heal", "Исцеление", 30, 200, Spells::heal);
        reg("barrier", "Магический барьер", 40, 400, Spells::barrier);
        reg("poison_cloud", "Ядовитое облако", 35, 300, Spells::poisonCloud);
        // --- бой (без маны) ---
        reg("dash", "Рывок", 0, 120, Spells::dash);
        reg("whirlwind", "Вихрь клинков", 0, 200, Spells::whirlwind);
        reg("war_cry", "Боевой клич", 0, 400, Spells::warCry);
        reg("leap_slam", "Удар с прыжка", 0, 240, Spells::leapSlam);
        reg("blade_throw", "Бросок клинка", 0, 100, Spells::bladeThrow);
        reg("blood_rage", "Кровавая ярость", 0, 500, Spells::bloodRage);
        reg("crushing_blow", "Сокрушающий удар", 0, 160, Spells::crushing);
        reg("stone_skin", "Каменная кожа", 0, 400, Spells::stoneSkin);
        reg("shadow_step", "Теневой шаг", 0, 140, Spells::shadowStep);
    }

    /** @param viaWeapon true — применение через ПКМ с оружием (изучение способности не требуется) */
    public static boolean cast(ServerPlayerEntity p, String id, boolean viaWeapon) {
        Ability a = ALL.get(id);
        if (a == null) return false;
        if (!viaWeapon) {
            boolean has = false;
            for (String u : PlayerSkills.get(p).unlocked()) {
                Skill s = Skills.get(u);
                if (s != null && id.equals(s.ability)) { has = true; break; }
            }
            if (!has) { Fx.msg(p, "Способность не изучена"); return false; }
        }
        String key = viaWeapon ? "w_" + id : id;
        int left = PlayerSkills.cdLeft(p, key);
        if (left > 0) {
            Fx.msg(p, a.name() + ": перезарядка " + String.format(Locale.ROOT, "%.1f", left / 20.0) + " с");
            return false;
        }
        Map<Stat, Double> st = PlayerSkills.stats(p);
        double costMul = 1.0 - Math.min(0.6, st.getOrDefault(Stat.MANA_COST_RED, 0.0));
        float cost = viaWeapon ? 0f : (float) Math.ceil(a.mana() * costMul);
        if (PlayerSkills.mana(p) < cost) { Fx.msg(p, "Недостаточно маны (" + (int) cost + ")"); return false; }

        boolean ok;
        try { ok = a.cast().run(p); }
        catch (Throwable t) { SkillTreeMod.LOG.error("Ошибка способности " + id, t); ok = false; }
        if (!ok) return false;

        PlayerSkills.addMana(p, -cost);
        double cdMul = 1.0 - Math.min(0.6, st.getOrDefault(Stat.COOLDOWN_RED, 0.0));
        int cd = (int) Math.ceil(a.cooldown() * cdMul);
        PlayerSkills.setCd(p, key, viaWeapon ? Math.max(cd, 100) : cd);
        Net.sync(p);
        return true;
    }
}
