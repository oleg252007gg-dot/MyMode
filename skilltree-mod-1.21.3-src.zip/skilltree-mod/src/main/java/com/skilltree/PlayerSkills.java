package com.skilltree;

import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

import java.util.*;

/** Серверная логика прокачки: очки, изучение, статы, мана, перезарядки. */
public final class PlayerSkills {
    public static final float BASE_MANA = 100f;
    public static final double BASE_REGEN = 2.0; // маны в секунду

    public static final Map<UUID, Float> MANA = new HashMap<>();
    public static final Map<UUID, Map<String, Integer>> CD = new HashMap<>();
    private record Cached(SkillData data, Map<Stat, Double> map) {}
    private static final Map<UUID, Cached> CACHE = new HashMap<>();

    public static SkillData get(ServerPlayerEntity p) { return p.getAttachedOrElse(SkillTreeMod.DATA, SkillData.EMPTY); }
    public static void set(ServerPlayerEntity p, SkillData d) { p.setAttached(SkillTreeMod.DATA, d); }

    public static void clearAll() { MANA.clear(); CD.clear(); CACHE.clear(); }

    // ---------------------------------------------------------------- статы
    public static Map<Stat, Double> stats(ServerPlayerEntity p) {
        SkillData d = get(p);
        Cached c = CACHE.get(p.getUuid());
        if (c != null && c.data() == d) return c.map();
        EnumMap<Stat, Double> m = new EnumMap<>(Stat.class);
        for (String id : d.unlocked()) {
            Skill s = Skills.get(id);
            if (s == null) continue;
            for (Map.Entry<Stat, Double> e : s.stats.entrySet()) m.merge(e.getKey(), e.getValue(), Double::sum);
        }
        CACHE.put(p.getUuid(), new Cached(d, m));
        return m;
    }

    public static double stat(ServerPlayerEntity p, Stat s) { return stats(p).getOrDefault(s, 0.0); }

    /** Пересчитывает ванильные атрибуты игрока (здоровье, броня, скорость и т.д.). */
    public static void applyStats(ServerPlayerEntity p) {
        Map<Stat, Double> st = stats(p);
        float oldMax = p.getMaxHealth();
        for (Stat s : Stat.values()) {
            if (s.attr == null) continue;
            RegistryEntry<EntityAttribute> entry = AttrUtil.get(s.attr);
            if (entry == null) continue;
            EntityAttributeInstance inst = p.getAttributeInstance(entry);
            if (inst == null) continue;
            Identifier id = Identifier.of(SkillTreeMod.MOD_ID, "stat_" + s.name().toLowerCase(Locale.ROOT));
            inst.removeModifier(id);
            double v = st.getOrDefault(s, 0.0);
            if (v != 0) inst.addPersistentModifier(new EntityAttributeModifier(id, v, s.op));
        }
        float newMax = p.getMaxHealth();
        if (newMax > oldMax) p.heal(newMax - oldMax);
        if (p.getHealth() > newMax) p.setHealth(newMax);
    }

    // ---------------------------------------------------------------- мана
    public static float maxMana(ServerPlayerEntity p) { return BASE_MANA + (float) stat(p, Stat.MAX_MANA); }
    public static float mana(ServerPlayerEntity p) { return MANA.getOrDefault(p.getUuid(), maxMana(p)); }
    public static void addMana(ServerPlayerEntity p, float delta) {
        MANA.put(p.getUuid(), Math.max(0f, Math.min(maxMana(p), mana(p) + delta)));
    }

    // ---------------------------------------------------------------- перезарядки
    public static int cdLeft(ServerPlayerEntity p, String key) {
        Map<String, Integer> m = CD.get(p.getUuid());
        if (m == null || p.getServer() == null) return 0;
        Integer end = m.get(key);
        return end == null ? 0 : Math.max(0, end - p.getServer().getTicks());
    }
    public static void setCd(ServerPlayerEntity p, String key, int ticks) {
        if (p.getServer() == null) return;
        CD.computeIfAbsent(p.getUuid(), k -> new HashMap<>()).put(key, p.getServer().getTicks() + ticks);
    }

    // ---------------------------------------------------------------- действия
    public static void handleAction(ServerPlayerEntity p, Net.ActionPayload a) {
        switch (a.action()) {
            case "unlock" -> unlock(p, a.arg());
            case "points" -> { if (SkillTreeMod.FREE_POINTS) addPoints(p, parse(a.arg())); }
            case "reset" -> reset(p);
            case "cast" -> Abilities.cast(p, a.arg(), false);
            default -> { }
        }
    }

    private static long parse(String s) {
        try { return Long.parseLong(s.trim()); } catch (Exception e) { return 0; }
    }

    public static void addPoints(ServerPlayerEntity p, long n) {
        if (n <= 0) return;
        SkillData d = get(p);
        int np = (int) Math.min(2_000_000_000L, (long) d.points() + Math.min(n, 1_000_000_000L));
        set(p, d.withPoints(np));
        Fx.msg(p, "Получено очков навыков: +" + n);
        Net.sync(p);
    }

    public static void unlock(ServerPlayerEntity p, String id) {
        Skill s = Skills.get(id);
        if (s == null) return;
        SkillData d = get(p);
        if (d.has(id)) {                       // повторный клик по оружию — выдать ещё раз
            if (s.grant != null) { giveItem(p, s); }
            return;
        }
        if (s.parent != null && !d.has(s.parent)) { Fx.msg(p, "Сначала изучите: " + Skills.get(s.parent).name); return; }
        if (d.points() < s.cost) { Fx.msg(p, "Не хватает очков: нужно " + s.cost); return; }
        List<String> l = new ArrayList<>(d.unlocked());
        l.add(id);
        set(p, d.withPoints(d.points() - s.cost).withUnlocked(l));
        applyStats(p);
        if (s.grant != null) giveItem(p, s);
        Fx.msg(p, "Изучено: " + s.name);
        Fx.sound(Fx.w(p), p.getPos(), SoundEvents.ENTITY_PLAYER_LEVELUP, 0.6f, 1.4f);
        Net.sync(p);
    }

    private static void giveItem(ServerPlayerEntity p, Skill s) {
        p.getInventory().offerOrDrop(new net.minecraft.item.ItemStack(s.grant));
        Fx.msg(p, "Получено: " + s.name);
    }

    public static void reset(ServerPlayerEntity p) {
        SkillData d = get(p);
        int refund = 0;
        for (String id : d.unlocked()) { Skill s = Skills.get(id); if (s != null) refund += s.cost; }
        set(p, new SkillData((int) Math.min(2_000_000_000L, (long) d.points() + refund), List.of(), d.kills()));
        applyStats(p);
        Fx.msg(p, "Навыки сброшены, очки возвращены: " + refund);
        Net.sync(p);
    }

    public static void addKill(ServerPlayerEntity p) {
        SkillData d = get(p);
        int k = d.kills() + 1;
        if (k % 10 == 0) {
            set(p, d.withKills(k).withPoints(d.points() + 1));
            Fx.msg(p, "+1 очко навыков (10 убийств)");
            Net.sync(p);
        } else {
            set(p, d.withKills(k));
        }
    }
}
