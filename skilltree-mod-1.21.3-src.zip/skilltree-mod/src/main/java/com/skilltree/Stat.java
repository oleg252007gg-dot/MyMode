package com.skilltree;

import net.minecraft.entity.attribute.EntityAttributeModifier.Operation;

/** Числовые бонусы навыков. Первые — ванильные атрибуты, остальные — логика мода. */
public enum Stat {
    // --- ванильные атрибуты ---
    MAX_HEALTH("max_health", Operation.ADD_VALUE),
    ARMOR("armor", Operation.ADD_VALUE),
    ARMOR_TOUGHNESS("armor_toughness", Operation.ADD_VALUE),
    MOVE_SPEED("movement_speed", Operation.ADD_MULTIPLIED_BASE),
    KB_RESIST("knockback_resistance", Operation.ADD_VALUE),
    LUCK("luck", Operation.ADD_VALUE),
    JUMP("jump_strength", Operation.ADD_VALUE),
    STEP_HEIGHT("step_height", Operation.ADD_VALUE),
    SAFE_FALL("safe_fall_distance", Operation.ADD_VALUE),
    BLOCK_REACH("block_interaction_range", Operation.ADD_VALUE),
    ENTITY_REACH("entity_interaction_range", Operation.ADD_VALUE),
    OXYGEN("oxygen_bonus", Operation.ADD_VALUE),
    ATTACK_DAMAGE("attack_damage", Operation.ADD_VALUE),
    ATTACK_DAMAGE_PCT("attack_damage", Operation.ADD_MULTIPLIED_TOTAL),
    ATTACK_SPEED_PCT("attack_speed", Operation.ADD_MULTIPLIED_BASE),

    // --- магия ---
    MAX_MANA, MANA_REGEN, SPELL_POWER, COOLDOWN_RED, MANA_COST_RED, FIRE_POWER, FROST_POWER, MANA_SHIELD,

    // --- бой ---
    LIFESTEAL, CRIT_CHANCE, CRIT_DAMAGE, DODGE, THORNS, EXECUTE, BLEED, ARMOR_PEN,
    WEAPON_MASTERY, BERSERK, KILL_HEAL, KILL_SPEED,

    // --- общее ---
    HUNGER_SAVE, REGEN, SATURATION, HASTE, NIGHT_VISION, WATER_BREATHING, FIRE_RES,
    IMMUNE_POISON, IMMUNE_WITHER, IMMUNE_HUNGER, MAGNET, SECOND_WIND;

    public final String attr;
    public final Operation op;

    Stat() { this(null, null); }
    Stat(String attr, Operation op) { this.attr = attr; this.op = op; }
}
