package com.skilltree;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.Map;

public final class Net {
    /** Клиент -> сервер: unlock / points / reset / cast. */
    public record ActionPayload(String action, String arg) implements CustomPayload {
        public static final CustomPayload.Id<ActionPayload> ID =
                new CustomPayload.Id<>(Identifier.of(SkillTreeMod.MOD_ID, "action"));
        public static final PacketCodec<RegistryByteBuf, ActionPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.STRING, ActionPayload::action,
                PacketCodecs.STRING, ActionPayload::arg,
                ActionPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Сервер -> клиент: очки, мана, изученные навыки, перезарядки. */
    public record SyncPayload(int points, int mana, int maxMana, String unlocked, String cooldowns) implements CustomPayload {
        public static final CustomPayload.Id<SyncPayload> ID =
                new CustomPayload.Id<>(Identifier.of(SkillTreeMod.MOD_ID, "sync"));
        public static final PacketCodec<RegistryByteBuf, SyncPayload> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, SyncPayload::points,
                PacketCodecs.VAR_INT, SyncPayload::mana,
                PacketCodecs.VAR_INT, SyncPayload::maxMana,
                PacketCodecs.STRING, SyncPayload::unlocked,
                PacketCodecs.STRING, SyncPayload::cooldowns,
                SyncPayload::new);
        @Override public Id<? extends CustomPayload> getId() { return ID; }
    }

    public static void init() {
        PayloadTypeRegistry.playC2S().register(ActionPayload.ID, ActionPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(SyncPayload.ID, SyncPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(ActionPayload.ID,
                (payload, context) -> PlayerSkills.handleAction(context.player(), payload));
    }

    public static void sync(ServerPlayerEntity p) {
        SkillData d = PlayerSkills.get(p);
        StringBuilder cd = new StringBuilder();
        if (p.getServer() != null) {
            int now = p.getServer().getTicks();
            Map<String, Integer> m = PlayerSkills.CD.get(p.getUuid());
            if (m != null) {
                for (Map.Entry<String, Integer> e : m.entrySet()) {
                    if (e.getValue() > now) {
                        if (cd.length() > 0) cd.append(';');
                        cd.append(e.getKey()).append('=').append(e.getValue() - now);
                    }
                }
            }
        }
        ServerPlayNetworking.send(p, new SyncPayload(
                d.points(),
                Math.round(PlayerSkills.mana(p)),
                Math.round(PlayerSkills.maxMana(p)),
                String.join(",", d.unlocked()),
                cd.toString()));
    }
}
