package com.skilltree;

import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;

import java.util.EnumMap;
import java.util.Map;

public final class Skill {
    public final String id, name, desc;
    public final ItemConvertible icon;
    public final int cost;
    public Branch branch;
    public String parent;
    public int col, row;
    public String ability;   // id способности (кнопка R)
    public Item grant;       // оружие, выдаваемое при изучении
    public final Map<Stat, Double> stats = new EnumMap<>(Stat.class);
    private ItemStack stack;

    public Skill(String id, String name, String desc, ItemConvertible icon, int cost) {
        this.id = id; this.name = name; this.desc = desc; this.icon = icon; this.cost = cost;
    }

    public Skill s(Stat st, double v) { stats.put(st, v); return this; }
    public Skill ab(String a) { ability = a; return this; }
    public Skill gr(Item i) { grant = i; return this; }

    public ItemStack stack() {
        if (stack == null) stack = new ItemStack(icon);
        return stack;
    }
}
